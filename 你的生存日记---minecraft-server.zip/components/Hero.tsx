import React, { useState, useEffect } from 'react';
import { Copy, Check, Signal, Users, Server as ServerIcon } from 'lucide-react';
import { fetchServerStatus } from '../services/mcService';
import { ServerStatus } from '../types';

export const Hero: React.FC = () => {
  const [status, setStatus] = useState<ServerStatus | null>(null);
  const [loading, setLoading] = useState(true);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    const loadStatus = async () => {
      try {
        // Use the actual IP requested
        const data = await fetchServerStatus('51mc.xyz');
        setStatus(data);
      } finally {
        setLoading(false);
      }
    };
    loadStatus();
    // Refresh every 60 seconds
    const interval = setInterval(loadStatus, 60000);
    return () => clearInterval(interval);
  }, []);

  const handleCopy = () => {
    navigator.clipboard.writeText('51mc.xyz');
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div id="hero" className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Image with Overlay */}
      <div 
        className="absolute inset-0 bg-cover bg-center z-0 scale-105 animate-pulse-slow"
        style={{ 
          backgroundImage: 'url("https://picsum.photos/1920/1080?grayscale&blur=2")',
          filter: 'brightness(0.4)'
        }}
      />
      
      {/* Decorative Grid */}
      <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-20 z-0 pointer-events-none"></div>

      <div className="relative z-10 max-w-5xl mx-auto px-4 text-center">
        {/* Badge */}
        <div className="inline-flex items-center px-4 py-1.5 rounded-full border border-green-500/30 bg-green-900/30 text-green-300 text-sm font-semibold mb-8 backdrop-blur-sm">
          <span className="w-2 h-2 rounded-full bg-green-400 mr-2 animate-pulse"></span>
          1.21.8 正式版上线
        </div>

        {/* Title */}
        <h1 className="text-5xl md:text-7xl font-black text-white tracking-tight mb-6 drop-shadow-2xl">
          开启你的 <span className="text-transparent bg-clip-text bg-gradient-to-r from-green-400 to-emerald-600">生存日记</span>
        </h1>
        
        <p className="text-lg md:text-xl text-gray-300 max-w-2xl mx-auto mb-10 leading-relaxed">
          体验最纯粹的 Minecraft 原版生存。没有繁杂的指令，只有纯粹的冒险。
          <br className="hidden md:block"/>
          在这里，每一个方块都是你的故事。
        </p>

        {/* Server IP Copy Box */}
        <div className="bg-slate-800/50 backdrop-blur-lg border border-slate-600 p-2 rounded-2xl inline-flex items-center space-x-2 mb-12 shadow-2xl hover:border-green-500/50 transition-colors group">
          <div className="px-6 py-3 text-white font-mono text-xl tracking-wide flex items-center">
            <span className="text-green-400 mr-2">{'>'}</span> 51mc.xyz
          </div>
          <button 
            onClick={handleCopy}
            className={`p-3 rounded-xl font-bold text-white transition-all duration-200 flex items-center space-x-2 ${
              copied ? 'bg-green-600' : 'bg-blue-600 hover:bg-blue-500'
            }`}
          >
            {copied ? <Check size={20} /> : <Copy size={20} />}
            <span className="text-sm">{copied ? '已复制' : '复制 IP'}</span>
          </button>
        </div>

        {/* Status Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 max-w-3xl mx-auto">
          {/* Players */}
          <div className="bg-slate-900/60 backdrop-blur-md p-6 rounded-2xl border border-slate-700 flex flex-col items-center hover:bg-slate-800/60 transition">
            <Users className="text-blue-400 mb-2" size={32} />
            <div className="text-2xl font-bold text-white">
              {loading ? '...' : status?.online ? status.players.online : '-'} 
              <span className="text-sm text-gray-400 font-normal mx-1">/</span>
              <span className="text-lg text-gray-500 font-medium">{loading ? '...' : status?.online ? status.players.max : '-'}</span>
            </div>
            <div className="text-xs text-gray-400 uppercase tracking-widest mt-1">在线玩家</div>
          </div>

          {/* Connection */}
          <div className="bg-slate-900/60 backdrop-blur-md p-6 rounded-2xl border border-slate-700 flex flex-col items-center hover:bg-slate-800/60 transition">
            <Signal className="text-green-400 mb-2" size={32} />
            <div className="text-2xl font-bold text-white">
              {loading ? '...' : status?.online ? (status.latency || 24) + 'ms' : 'Offline'}
            </div>
            <div className="text-xs text-gray-400 uppercase tracking-widest mt-1">网络延迟</div>
          </div>

          {/* Version */}
          <div className="bg-slate-900/60 backdrop-blur-md p-6 rounded-2xl border border-slate-700 flex flex-col items-center hover:bg-slate-800/60 transition">
            <ServerIcon className="text-purple-400 mb-2" size={32} />
            <div className="text-2xl font-bold text-white">
              1.21.8
            </div>
            <div className="text-xs text-gray-400 uppercase tracking-widest mt-1">服务器版本</div>
          </div>
        </div>
      </div>
      
      {/* Scroll Down Indicator */}
      <div className="absolute bottom-10 left-1/2 transform -translate-x-1/2 animate-bounce text-gray-500">
        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
        </svg>
      </div>
    </div>
  );
};