import React from 'react';
import { Github, Twitter, MessageCircle } from 'lucide-react';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-slate-950 border-t border-slate-800 pt-16 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
          <div className="col-span-1 md:col-span-2">
            <h3 className="text-2xl font-bold text-white mb-4">你的生存日记</h3>
            <p className="text-slate-400 max-w-sm mb-6">
              这是一个致力于还原最初感动的 Minecraft 原版生存服务器。在这里，你可以放下现实的疲惫，拿起方块，构建属于你的世界。
            </p>
            <div className="flex space-x-4">
               {/* Placeholder social links */}
               <a href="#" className="p-2 bg-slate-800 rounded-full text-slate-400 hover:text-white hover:bg-blue-600 transition">
                 <Twitter size={20} />
               </a>
               <a href="#" className="p-2 bg-slate-800 rounded-full text-slate-400 hover:text-white hover:bg-gray-700 transition">
                 <Github size={20} />
               </a>
            </div>
          </div>
          
          <div>
            <h4 className="text-lg font-semibold text-white mb-4">快速链接</h4>
            <ul className="space-y-2">
              <li><a href="#hero" className="text-slate-400 hover:text-green-400 transition">回到首页</a></li>
              <li><a href="#features" className="text-slate-400 hover:text-green-400 transition">服务器特色</a></li>
              <li><a href="#download" className="text-slate-400 hover:text-green-400 transition">下载中心</a></li>
              <li><a href="#" className="text-slate-400 hover:text-green-400 transition">赞助支持</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-lg font-semibold text-white mb-4">联系我们</h4>
            <ul className="space-y-3">
              <li className="flex items-center text-slate-400">
                <MessageCircle size={18} className="mr-2" />
                <span>QQ群: 123456 (示例)</span>
              </li>
              <li className="text-slate-400 text-sm">
                管理员邮箱: <br/> admin@51mc.xyz
              </li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-slate-900 pt-8 flex flex-col md:flex-row justify-between items-center text-sm text-slate-500">
          <p>© 2024 你的生存日记. Not affiliated with Mojang AB.</p>
          <p className="mt-2 md:mt-0">Design with ❤️ for Minecraft Players</p>
        </div>
      </div>
    </footer>
  );
};