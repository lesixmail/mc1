import React from 'react';
import { Download as DownloadIcon, Smartphone, Monitor } from 'lucide-react';

export const Download: React.FC = () => {
  return (
    <section id="download" className="py-24 bg-gradient-to-b from-slate-900 to-slate-950 relative overflow-hidden">
      {/* Abstract Shapes */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2"></div>
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-green-500/10 rounded-full blur-3xl translate-y-1/2 -translate-x-1/2"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="flex flex-col lg:flex-row items-center justify-between gap-12">
          
          <div className="lg:w-1/2 text-left">
            <h2 className="text-3xl md:text-5xl font-bold text-white mb-6 leading-tight">
              准备好开始<br/>
              <span className="text-green-400">你的冒险</span>了吗？
            </h2>
            <p className="text-slate-300 text-lg mb-8 leading-relaxed">
              为了保证最佳的游戏体验，我们推荐使用官方启动器或常用的第三方启动器（如 PCL2, HMCL）。
              <br/><br/>
              如果你是首次接触 Minecraft，可以下载我们打包好的整合包，解压即玩，内置了优化模组。
            </p>
            
            <div className="flex flex-wrap gap-4">
              <button disabled className="flex items-center space-x-3 px-8 py-4 bg-white text-slate-900 rounded-xl font-bold hover:bg-gray-100 transition shadow-lg opacity-75 cursor-not-allowed">
                <Monitor className="w-5 h-5" />
                <span>Windows 客户端 (敬请期待)</span>
              </button>
              <button disabled className="flex items-center space-x-3 px-8 py-4 bg-slate-800 text-white rounded-xl font-bold border border-slate-700 hover:bg-slate-700 transition opacity-75 cursor-not-allowed">
                <Smartphone className="w-5 h-5" />
                <span>移动端 (PE/Bedrock)</span>
              </button>
            </div>
            <p className="mt-4 text-sm text-slate-500 flex items-center">
              <DownloadIcon className="w-4 h-4 mr-2" />
              当前版本: 1.21.8 | 最后更新: 2024-05
            </p>
          </div>

          <div className="lg:w-1/2 relative">
             <div className="relative rounded-2xl overflow-hidden shadow-2xl border-4 border-slate-700/50 transform rotate-1 hover:rotate-0 transition duration-500">
               <img 
                 src="https://picsum.photos/800/600?grayscale" 
                 alt="Game Screenshot" 
                 className="w-full h-auto object-cover opacity-80 hover:opacity-100 transition-opacity duration-500"
               />
               <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-transparent to-transparent"></div>
               <div className="absolute bottom-6 left-6 text-white">
                  <p className="font-bold text-lg">探索无限可能</p>
                  <p className="text-sm text-gray-300">加入 51mc.xyz</p>
               </div>
             </div>
          </div>

        </div>
      </div>
    </section>
  );
};