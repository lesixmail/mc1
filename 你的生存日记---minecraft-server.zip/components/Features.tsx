import React from 'react';
import { Shield, Zap, Heart, Compass, Sword, Hammer } from 'lucide-react';

const features = [
  {
    icon: <Compass className="w-8 h-8 text-orange-400" />,
    title: "原汁原味",
    desc: "坚持 1.21.8 原版生存机制，无破坏平衡的模组，带你找回最初的感动。"
  },
  {
    icon: <Shield className="w-8 h-8 text-green-400" />,
    title: "稳定运行",
    desc: "采用高性能独立物理机，全天候 DDOS 防护，确保你的冒险永不断线。"
  },
  {
    icon: <Heart className="w-8 h-8 text-red-400" />,
    title: "友善社区",
    desc: "严格的审核机制与活跃的管理团队，打造最温馨、素质最高的玩家社区。"
  },
  {
    icon: <Zap className="w-8 h-8 text-yellow-400" />,
    title: "低延迟",
    desc: "针对中国大陆网络优化的 BGP 线路，无论电信联通移动，均享丝滑体验。"
  },
  {
    icon: <Sword className="w-8 h-8 text-blue-400" />,
    title: "困难挑战",
    desc: "服务器设置为困难模式，定期举办末地远征与建筑大赛，奖励丰厚。"
  },
  {
    icon: <Hammer className="w-8 h-8 text-purple-400" />,
    title: "长期周目",
    desc: "我们承诺长期运营，不轻易删档，让你的宏伟建筑成为服务器的历史。"
  }
];

export const Features: React.FC = () => {
  return (
    <section id="features" className="py-24 bg-slate-900 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">为什么选择我们？</h2>
          <p className="text-slate-400 max-w-2xl mx-auto">
            我们不仅仅是一个服务器，更是一个属于每一个冒险家的家园。
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div 
              key={index}
              className="group bg-slate-800/50 p-8 rounded-2xl border border-slate-700 hover:border-green-500/30 hover:bg-slate-800 transition-all duration-300 hover:-translate-y-1"
            >
              <div className="bg-slate-900 rounded-xl p-4 inline-block mb-6 group-hover:scale-110 transition-transform duration-300 shadow-lg">
                {feature.icon}
              </div>
              <h3 className="text-xl font-bold text-white mb-3">{feature.title}</h3>
              <p className="text-slate-400 leading-relaxed">
                {feature.desc}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};